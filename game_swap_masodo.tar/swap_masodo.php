<?php
/*--------------------------------------------------*/
/* File Created by PracticalLightning Arcade 1.0!	    */
/* File Generated:     2019-05-10 12:24:37                             */
/*--------------------------------------------------*/

$config = array(
	'active'			=> '1',
	'bgcolor'			=> '000000',
	'gcat'			=> '6',
	'gheight'			=> '785',
	'gkeys'			=> '',
	'gname'			=> 'swap_masodo',
	'gtitle'			=> 'SWAP',
	'gwidth'			=> '675',
	'gwords'			=> 'SWAP which character you controll to reach your goal. Careful, as characters youre not controlling will often have a mind of their own! Progress through many tricky and challenging levels, and watch as that death count piles up ;)',
	'highscore_type'			=> 'high',
	'object'			=> 'SWAP which character you controll to reach your goal. Careful, as characters youre not controlling will often have a mind of their own! Progress through many tricky and challenging levels, and watch as that death count piles up ;)',
	'snggame'			=> '0',
);
?>